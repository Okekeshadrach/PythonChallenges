file = open("Names.txt", "r")
newname = input("Enter a new name: ")
file.write(newname + "\n")
file.close()

file = open("Names.txt", "r")
print (file.read())
file.close