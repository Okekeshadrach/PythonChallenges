list = [[2,5,8],[3,7,4],[1,6,9],[4,2,0]]
row = int(input("Select a row: "))
print(list[row])
col = int(input("Select a column: "))
print(list[row] [col])
change = input("Do you want to change the value? (y/n) ")
if change == "y":
    newvalue = int(input("Enter  new number: "))
    list [row] [col] = newvalue
    print(list[row])
