kilo = int(input("Enter the number of kilo's: "))
pound = kilo * 2.204
print ("That is", pound,"pounds")