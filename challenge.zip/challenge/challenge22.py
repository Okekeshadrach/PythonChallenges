firstname = input("Enter Your first name lowercase: ")
surname = input("Enter Your surname in lowercase: ")
firstname = firstname.title()
surname = surname.title()
name = firstname + " " + surname
print(name)