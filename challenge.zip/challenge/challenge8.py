bill = int(input("Whats the total cost of the bill? "))
people = int(input("input how many people are there? "))
each = bill/people
print ("Each person should pay $",each)