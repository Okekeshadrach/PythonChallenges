colour = (input("Type in your favorite colour: "))
if colour == "red" or colour == "RED" or colour == "Red":
    print ("I like red too.")
else:
    print("I don't like that color, I prefer red")