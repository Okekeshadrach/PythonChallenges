name = input("Enter Your name: ")
length = len(name)
print(length)
