import random

colour = random.choice(["red","blue","green","white", "pink"])
print("select from red, blue, green, white or pink")
tryagain = True
while tryagain == True:
    theirchoice = input("enter a colour: ")
    theirchoice = theirchoice.lower()
    if colour == theirchoice:
        print("well done")
        tryagain = False
    else:
        if colour == "red":
            print("I bet you are seeing Red right now!")
        elif colour == "blue":
            print("don't feel BLUE.")
        elif colour == "green":
            print("I bet you are GREEN with envy right now.")
        elif colour == "white":
            print("Are you WHITE as a sheet, as you didn't guess correctly?")
        elif colour == "pink":
            print("shame you are not feeling in the PINK, as you got it wrong")
