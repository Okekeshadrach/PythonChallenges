num = 10
while num >0:
    print("there are ", num, "green bottles hanging on the wall.")
    print( num, "green bottle should accidentally fail,")
    num = num - 1
    answer = int(input("how many green bottles will be hanging in the wall? "))
    if answer == num:
        print("there will be," num, "green bottles hanging on the wall.")
    else: 
        while answer!=num:
            answer = int(input("no, try again: "))
print("there are no more green bottles hanging on the wall.")