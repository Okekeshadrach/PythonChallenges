file = open("Names.txt","r")
print(file.read())
file.close()