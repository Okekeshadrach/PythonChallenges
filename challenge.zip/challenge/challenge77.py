name1 = input("enter a name of somebody you want toinvite toyour party: ")
name2 = input("enter another name: ")
name3 = input("enter a third name: ")
party = [name1,name2,name3]
another = input("do you want to invite another (y/n): ")
while another == "y":
    newname = party.append(input("enter another name: "))
    another = input("do you want to invite another (y/n):")
print("you have",len(party), "people coming to your party")
print(party)
selection = input("enter one of the names: ")
print(selection,"is in position",party.index(selection), "on the list")
stillcome = input("do you still want them to come (y/n): ")
if stillcome == "n":
    party.remove(selection)
print(party)