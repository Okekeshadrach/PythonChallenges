name1 = input("enter a name of somebody you want to your party: ")
name2 = input("enter another name: ")
name3 = input("enter a third name: ")
party - [name1,name2,name3]
another = input("do you want to invite another (y/n): ")
while another == "y":
    newname = party.append(input("enter another name: "))
    another = input("do you want to invite another (y/n): ")