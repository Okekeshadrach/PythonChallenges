num = int(input("how many friends do you want to invite to the party? "))
if num< 10:
    for i in range(0,num):
        name = input("enter a new name: ")
        print(name, "has been invited")
else:
    print("too many people")