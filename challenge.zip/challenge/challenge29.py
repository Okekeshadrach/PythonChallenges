import math
num = int(input("enter a number over 500: "))
answer = math.sqrt(num)
print (round(answer, 2))