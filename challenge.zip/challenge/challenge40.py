num = int(input("enter a number below 50: "))
for i range(50,num-1, -1):
    print(1)
    