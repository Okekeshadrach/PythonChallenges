list = { }
for i in range (0,4):
    name = input("Enter name: ")
    age = int(input("Enter age: "))
    shoe = int(input("Enter shoe size: "))
    list[name] = {"Age":age, "Shoe size":shoe}
    
getrid = input("Who do you want to remove from the list: ")
del list[getrid]

for name in list:
    print((name), list[name] ["Age"], list[name]["Shoe size"])