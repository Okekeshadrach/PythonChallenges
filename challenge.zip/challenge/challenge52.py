import random
num = random.randint(1,100)
print(num)