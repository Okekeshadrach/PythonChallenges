from  array import *

nums = array('i',[5,7,9,2,9])
for i in nums:
    print(i)
    
num = int(input("Enter a number: "))

if nums.count(num) == 1:
    print(num, "is in the list once")
else:
    print(num, "is in the list", nums.count(num), "times")