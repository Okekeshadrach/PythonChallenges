num = int(input("Enter1, 2 or 3: "))
if num == "1":
    print("Thank you")
elif num == "2":
    print("well done")
elif num == "3":
    print("Correct")
else:
    print("Error message")
