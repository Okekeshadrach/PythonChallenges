postcode =input("enter your postcode: ")
start = postcode[0:2]
print (start.upper())