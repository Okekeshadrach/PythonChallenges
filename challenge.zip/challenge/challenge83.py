msg = input("Enter a message in uppercase: ")
tryagain = False
while tryagain == False:
	if msg.isupper():
		print("Thank you")
		tryagain = True
	else:
		print("Try again")
		msg = input("Enter a message in uppercase: ")