name = input("type in your name: ")
number = int(input("enter a number: "))
for i in range (0, number):
    print(name)