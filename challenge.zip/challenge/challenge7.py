name = input("Enter your Name: ")
age = int(input("Enter your age: "))
Newage = age + 1
print(name,"on your next birthday you will be",Newage)