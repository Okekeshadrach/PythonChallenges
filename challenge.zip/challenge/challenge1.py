firstname = input("Enter first name: ")
print ('Hello',firstname)
