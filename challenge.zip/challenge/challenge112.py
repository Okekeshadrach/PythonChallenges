import csv

file = open("Books.csv", "a")
title = input("Enter a title: ")
author = input("Enter author: ")
year = input("Enter the year it was released: ")
newrecord = title + "," + author + "," + year + "\n"
file.write(str(newrecord))
file.close()

file = open("Books.csv", "r")
for row in file:
    print(row)
file.close()