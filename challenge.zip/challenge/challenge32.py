import math
radius = int(input("enter the radius of the circle: "))
depth = int(input("enter depth: "))
area = math.pi*(radius**2)
volume = area*depth
print(round(volume, 3))