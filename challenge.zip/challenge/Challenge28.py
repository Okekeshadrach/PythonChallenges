num = float(input("enter a number with a lot of decimal places: "))
answer = num*2
print(answer)
print (round("answer, 2"))
