firstname = input("Enter First Name:")
Surname = input("Enter Surname: ")
print('Hello',firstname,Surname)