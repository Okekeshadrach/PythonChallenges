again = "y"
count = 0
while again == "y":
    name = input("Enter a name of somebody you want to invite ot your party:")
    print(name, "has now been invited.")
    count = count + 1
    again = input("Do you want to invite somebody else? (y/n) ")
print("you have", count, "people coming to your party")