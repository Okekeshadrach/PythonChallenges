num = int(input("enter a number; "))
name = input("enter your name: ")
for x in range(0,num):
    for i in name:
        print(i)
        