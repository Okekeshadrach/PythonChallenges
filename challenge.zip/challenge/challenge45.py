total = 0
while total <= 50:
    num = int(input("enter a number: "))
    total = total + num
    print("the total is...",total)
    