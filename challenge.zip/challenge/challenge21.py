firstname = input("Enter Your first name: ")
surname = input("Enter Your surname: ")
name = firstname + " " + surname
length = len(name)
print(name)
print(length)