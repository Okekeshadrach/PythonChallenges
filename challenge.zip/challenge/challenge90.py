From array import *
nums = array('1',[])
while len(nums) < 5:
    num = int(input("enter a number between 10 and 20: "))
    if num >= 10 and num <=20:
        nums.append(num)
    else:
        print("outside the range")
for i in nums:
    print(i)