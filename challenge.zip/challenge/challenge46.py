num = 0
while num <=5:
    num = int(input("enter a number: "))
print("the last number you entered was a", num)
