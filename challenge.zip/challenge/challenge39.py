num = int(input("enter a number between 1 and 12: "))
for i in range(1, 13):
    answer = 1 * num
    print (i, "x", num, "=", answer)
    