name = (input("enter your name: "))
for i in name:
    print