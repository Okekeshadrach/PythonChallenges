import turtle
for i  in range (0,3):
    turtle.forward(100)
    turtle.left(120)

    turtle.exitonclick()
