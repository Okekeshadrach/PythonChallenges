import turtle
for i in range (0,360):
    turtle.forward(1)
    turtle.right(1)
turtle.exitonclick()