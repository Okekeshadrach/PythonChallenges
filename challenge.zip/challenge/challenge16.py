raining = (input("Is it raining? "))
raining = str.lower(raining)
if raining == "Yes":
    windy = input("is it windy? ")
    windy = str.lower(windy)
    if windy == "yes":
        print("It is too windy for an umbrella")
    else:
        print("Take an umbrella")
else:
    print("Enjoy your day")