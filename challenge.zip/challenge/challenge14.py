num = int(input("Enter a value between 10 and 20: "))
if num >= 10 and num <= 20:
    print ("Thank you")
else:
    print("Incorrect answer")