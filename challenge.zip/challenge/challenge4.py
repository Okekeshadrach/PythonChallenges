num1 = int(input("Enter First Number: "))
num2 = int(input("Enter Second Number: "))
answer = num1 + num1
print('The total is',answer)