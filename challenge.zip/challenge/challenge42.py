total = 0
for i in range(0,5):
    num = int(input("enter a number "))
    ans = input("do you want this number included? (y/n) ")
    if ans == "y":
        total = total + num
print(total)