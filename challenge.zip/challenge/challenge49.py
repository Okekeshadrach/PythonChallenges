compnum = 50
guess = int(input("can you guess the number i am thinking of? "))
count = 1 
while guess != compnum:
    if guess < compnum:
        print("too low")
    else:
        print("too high")
    count = count+1
    guess = int(input("have another 2guess: "))
print("well done, you look," count, "attempts")