startNum = int(input("Enter the number of pizza you started with: "))
endNum = int(input("How many slice have you eaten: "))
sliceleft = startNum - endNum
print("You have", sliceleft, "slice remaining")